# Info About Data Sets

---
## Non-Messy Data
---

### Military expenditure of GDP

Source:		https://data.world/brianray/gapminder-military-expenditure
Set:			yes
Hierarchical:	no
Domain:		economics, military, social


### HDI Human Development Index

Source:		https://data.world/brianray/gapminder-hdi-human-developmen
Set:			yes
Hierarchical:	no
Domain:		economics, social


### Share of US Ad Spend

Source:		https://data.world/makeovermonday/2020w46
Set:			no
Hierarchical:	yes
Domain:		economics


### PRSA_Data_Aotizhongxin_20130301-20170228

Source:		https://archive.ics.uci.edu/ml/datasets/Beijing+Multi-Site+Air-Quality+Data
Set:			yes
Hierarchical:	no
Domain:		meterology, environment


### generation-by-fuel-type-1

Source:		https://data.world/cityofaustin/ss6t-rumq
Set:			yes
Hierarchical:	no
Domain:		environment, energy


### PRSA_data_2010.1.1-2014.12.31

Source:		https://archive.ics.uci.edu/ml/datasets/Beijing+PM2.5+Data
Set:			yes
Hierarchical:	no
Domain:		meteorology, environment


### weekly_fuel_prices_all_data_from_2005_to_20210823

Source:		https://data.world/rafabelokurows/weekly-fuel-prices-in-italy
Set:			yes
Hierarchical:	no
Domain:		energy, economics


### HPDD_06-13-2016 19-49-43-03_timeSeries

Source:		https://data.world/data-society/historical-public-debt-data
Set:			yes
Hierarchical:	no
Domain:		economics


### populationsg

Source:		https://data.world/hxchua/populationsg
Set:			no
Hierarchical:	yes
Domain:		social


### Union vs Non-Union Median Salaries

Source:		https://data.world/makeovermonday/2019w49
Set:			no
Hierarchical:	yes
Domain:		economics


### MM25

Source:		https://data.world/makeovermonday/2020w25-amazons-tiny-profits-explained
Set:			no
Hierarchical:	no
Domain:		economics


### Time Americans Spend Sleeping

Source:		https://data.world/makeovermonday/2019w23
Set:			no
Hierarchical:	yes
Domain:		health, social


### Weekly Fuel Prices

Source:		https://data.world/makeovermonday/2020w17-weekly-road-fuel-prices
Set:			yes
Hierarchical:	no
Domain:		economics, energy


### marine_institute_buoy_wave_forecast

Source:		https://data.world/marineinstitute/7f8e6a7d-91b6-4fb3-8d36-571b8a8e6052
Set:			yes
Hierarchical:	no
Domain:		environment


### performance-metrics-city-colleges-of-chicago-course-success-rates-1

Source:		https://data.world/cityofchicago/performance-metrics-city-colleges-of-chicago-course-s
Set:			yes
Hierarchical:	no
Domain:		education


### construction_price_index

Source:		https://data.world/finance/home-construction-price-index
Set:			yes
Hierarchical:	no
Domain:		economics


### Texas population by zip code, 2010-2016

Source:		https://data.world/lukewhyte/texas-population-by-zip-code-2011-2016
Set:			yes
Hierarchical:	no
Domain:		social


### milk-quota-by-county-1994-to-2008-1

Source:		https://data.world/datagov-uk/02b322f0-fd2a-497d-bad4-a3ee84e0d015
Set:			yes
Hierarchical:	yes
Domain:		economics, social


### pedestrian-and-bicyclist-counts-2017-8

Source:		https://data.world/city-of-bloomington/117733fb-31cb-480a-8b30-fbf425a690cd
Set:			yes
Hierarchical:	no
Domain:		social


### ebola-data-db-format-csv-1

Source:		https://data.world/hdx/0d089fa0-3567-4b01-9c03-39d340ff34e3
Set:			yes
Hierarchical:	no
Domain:		health


### Monthly Crude Oil Production by State 1981 - Nov 2016

Source:		https://data.world/garyhoov/oil-production-by-state
Set:			yes
Hierarchical:	yes
Domain:		energy, economics, environment


---
## Messy Data
---

### BMI-by-Country

Source: 		https://datarepository.wolframcloud.com/resources/BMI-by-Country/
Set:			yes
Hierarchical: 	no
Domain:		health


### Infectious-Diseases-by-Country-2009-2014

Source: 		https://datarepository.wolframcloud.com/resources/Infectious-Diseases-by-Country-2009-2014/
Set:			yes
Hierarchical: 	no
Domain:		health


### Prussian-Horse-Kick-Data

Source: 		https://datarepository.wolframcloud.com/resources/Prussian-Horse-Kick-Data
Set:			yes
Hierarchical:	no
Domain:		military


### U.S.+Suicide+Rates+by+County

Source:		https://datarepository.wolframcloud.com/resources/USSuicideRatesbyCounty
Set:			no (maybe?)
Hierarchical:	yes
Domain:		health, social


### Organ-Transplant-by-Country

Source: 		https://datarepository.wolframcloud.com/resources/Organ-Transplants-by-Country
Set:			yes
Hierarchical: 	no
Domain:		health







